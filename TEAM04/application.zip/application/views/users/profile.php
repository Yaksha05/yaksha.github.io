<?php
    $this->load->view('elements/header');
?>

<p>Ito ang profile</p>

<?php
    $this->load->view('elements/footer');
?>

