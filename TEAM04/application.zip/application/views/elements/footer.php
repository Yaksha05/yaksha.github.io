<!------- FOOTER ------->
<footer>
		<div class="socmed-links">
            <a href="<?php echo base_url(); ?>" target="_blank"> <i class="fab fa-facebook-f"></i></a>
            <a href="<?php echo base_url(); ?>" target="_blank"> <i class="fab fa-instagram"></i></a>
            <a href="<?php echo base_url(); ?>" target="_blank"> <i class="fab fa-twitter"></i></a>
            <a href="<?php echo base_url(); ?>" target="_blank"> <i class="fab fa-linkedin"></i></a>
        </div>
        <p>Copyright &copy;2021 E - PORTFOLIO | All Rights Reserved</p>
	</footer>
	